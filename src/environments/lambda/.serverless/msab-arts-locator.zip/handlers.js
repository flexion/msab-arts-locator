module.exports = {
  saveLocation: require('./lambdas/saveLocation').handler,
};
